<template>
  <div class="min-h-screen bg-gray-900 text-white">
    <Navbar/>
    
    <div class="main container mx-auto px-4 py-6">
      <router-view/>
    </div>
    <Footer></Footer>
  </div>
</template>
<script setup>
import Navbar from './components/NavbarComponent.vue'
import Footer from './components/FooterComponent.vue'
</script>
