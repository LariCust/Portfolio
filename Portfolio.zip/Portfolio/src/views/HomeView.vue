<template>
  <section class="flex items-center justify-center min-h-[80vh] bg-gray-900 px-6">
    <div class="text-center max-w-2xl">
      <h1 class="text-4xl md:text-5xl font-extrabold text-white">
        Bem-vindo ao meu <span class="text-purple-600">Portfólio</span>
      </h1>
      <p class="mt-6 text-lg text-gray-300">
        Sou estudante de <strong>Análise e Desenvolvimento de Sistemas</strong> na <strong>Unimar</strong>, sempre amei a área de tecnológia, mas minhas preferências são voltadas ao design de interface, como o UX/UI Design e Desenvolvimento Web.
      </p>
      <div class="mt-8">
        <router-link to="/sobre" class="inline-block bg-purple-500 text-white font-bold px-6 py-2 rounded-full border border-transparent hover:bg-gray-900 hover:border-purple-600 transition duration-300">
          Sobre mim
        </router-link>
      </div>
    </div>
  </section>
</template>



