<template>
  <nav class="bg-gray-800 text-white p-4 relative">
    <div class="flex justify-center items-center relative text-purple-600">
      <div class="absolute left-0 space-x-4">
        <router-link class="hover:underline" to="/">Home</router-link>
        <router-link class="hover:underline" to="/sobre">Sobre</router-link>
        <router-link class="hover:underline" to="/contato">Contato</router-link>
      </div>
      <div class="text-lg font-bold">Meu Portfólio</div>
    </div>
  </nav>
</template>
