<template>
    <footer class="bg-gray-800 text-purple-600 p-4 fixed text-center bottom-0 w-full mt-8">
        <p>2025 Larissa Vitoria Custodio - ADS - Unimar</p>
    </footer>
</template>